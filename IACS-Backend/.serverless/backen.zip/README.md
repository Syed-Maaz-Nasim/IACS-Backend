# IACS


Industrial Academia Coordination system motive to provide a communication between students and industries
