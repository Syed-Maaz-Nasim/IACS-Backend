'use strict';

const app = require('./app');
const Serverless = require('serverless-http')
module.exports.hello = Serverless(app);
 